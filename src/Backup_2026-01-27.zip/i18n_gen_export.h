// Auto-generated from CSV — DO NOT EDIT MANUALLY
#pragma once
#include <stddef.h>

struct Entry {
    const char* key;
    const char* en;
    const char* hr;
    const char* de;
    const char* fr;
    const char* es;
};

extern "C" {
    extern const Entry* g_i18n_gen_table;
    extern const size_t g_i18n_gen_count;
}
