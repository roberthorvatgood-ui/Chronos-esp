
#pragma once
#include <lvgl.h>
#ifdef __cplusplus
extern "C" {
#endif

LV_FONT_DECLARE(ui_font_28);

#ifdef __cplusplus
}
#endif
