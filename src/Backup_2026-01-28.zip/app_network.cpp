
/*******************************************************
 * app_network.cpp — AP-only stub
 * [2026-01-20 23:05 CET] RH
 *
 * All functions are defined inline in app_network.h as no-ops.
 * This TU is intentionally empty.
 *******************************************************/
#include "app_network.h"
// Nothing else to do in AP-only build.
